/** Automatically generated file. DO NOT MODIFY */
package com.philips.codered;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}